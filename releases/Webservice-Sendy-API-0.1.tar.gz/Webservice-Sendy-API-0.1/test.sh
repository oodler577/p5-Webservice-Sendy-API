curl -v -X POST https://crm.acutisdata.com/sendy/unsubscribe.php \
    -d "api_key=YtYbpUY7BGHqGeRpNhIn"  \
    -d "list=B7Y1B5ntJ2iWJ2eHTm892GOQ" \
    -d "email=mrhppyguy@aol.co"        \
